<?php
include 'koneksi.php';

if(isset($_POST['simpan'])){
    mysqli_query($conn, "INSERT INTO obat VALUES(
        '',
        '$_POST[nama_obat]',
        '$_POST[dosis]',
        '$_POST[stok]'
    )");

    header("location.inndex.php");

}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Obat</title>
</head>
<body>


<h2>Tambah Data Obat</h2>

<form method="POST">
    <input type="text" name="nama_obat" placeholder="Nama Obat" require><br><br>

    <input type="text" name="dosis" placeholder="Dosis" require><br><br>

    <input type="number" name="stok" placeholder="Stok" require><br><br>

    <button type="submit" name="simpan">Simpan</button>
</form>


</body>
</html>