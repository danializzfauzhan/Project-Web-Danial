<?php
$conn = mysqli_connect("localhost", "root", "", "apotek_mini");

if(!$conn){
    die("koneksi gagal"
    );
}
?>