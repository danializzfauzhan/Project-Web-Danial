CREATE DATABASE apotek_mmini;
CREATE TABLE obat (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_obat VARCHAR(100),
    dosis VARCHAR(50),
    stok INT
);