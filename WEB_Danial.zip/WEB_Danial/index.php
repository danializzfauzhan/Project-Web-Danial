<?php
include 'koneksi.php';
$data = mysqli_query($conn, "SELECT * FROM obat");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Apotek Mini</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>


<h2>Inventaris Apotek Mini</h2>

<a href="tambah.php" class="btn">+ Tambah Obat</a>

<table>
    <tr>
        <th>no</th>
        <th>Nama Obat</th>
        <th>Dosis</th>
        <th>Stok</th>
        <th>Aksi</th>
    </tr>

    <?php
    $no = 1;
    while($d =mysqli_fetch_array($data)){
    ?>

    <tr>
        <td><?= $no++; ?></td>
        <td><?= $d['nama_obat']; ?></td>
        <td><?= $d['dosis']; ?></td>
        <td><?= $d['stok']; ?></td>
        <td>
            <a href="edit.php?id=<?= $d['id']; ?>">Edit</a>
            <a href="hapus.php?id=<?= $d['id']; ?>">Hapus</a>
        </td>
    </tr>
    <?php } ?>
</table>


</body>
</html>