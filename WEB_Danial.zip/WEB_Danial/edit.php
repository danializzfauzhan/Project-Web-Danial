<?php
include 'koneksi.php';

$id = $_GET['id'];

$data = mysqli_query($conn, "SELECT * FROM obat WHERE id='$id'");
$d = mysqli_fetch_array($data);


if(isset($_POST['update'])){
    mysqli_query($conn, "UPDATE obat SET
        nama_obat='$_POST[nama_obat]',
        dosis='$_POST[dosis]',
        stok='$_POST[stok]'
        WHERE id='$id'
    ");
    
    header("location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Obat</title>
</head>
<body>
    

<h2>Edit Data Obat</h2>
<form method="POST">
    <input type="text" name="nama_obat"  value="<?+ $d['nama_obat']; ?>" require><br><br> 

    <input type="text" name="dosis"  value="<?= $d['dosis']; ?>" require><br><br>

    <input type="number" name="stok" value="<?= $d['stok']; ?>" require><br><br>

    <button type="submit" name="update">Update</button>
</form>


</body>
</html>